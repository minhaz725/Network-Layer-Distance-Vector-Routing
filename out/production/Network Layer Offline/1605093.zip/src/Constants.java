//Done!
package src;
public interface Constants {

    final int INFINITY = 10;
    final double LAMBDA = 0.10;

}